<script setup>
    import formulario from './components/formulario.vue'
</script>

<template>
  <formulario/>
</template>

<style scoped>

</style>
