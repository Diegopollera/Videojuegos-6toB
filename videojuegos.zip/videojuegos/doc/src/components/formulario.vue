<template>
  <div class="container">
    <div class="content-box">
      <h1>Administrar videojuegos</h1>
      <table>
        <tr>
          <th>
            <div class="contenedor">
              <div class="form-group">
                <label for="">Nombre</label>
                <input type="text" v-model="videojuego.nombre"><br>
                <label for="">Plataforma</label>
                <select v-model="videojuego.plataforma">
                  <option value="pc">PC</option>
                  <option value="play">PlayStation</option>
                  <option value="xbox">Xbox One</option>
                </select>
                <label for="">Estado</label>
                <select v-model="videojuego.estado">
                  <option value="Pendiente">Pendiente</option>
                  <option value="Jugando">Jugando</option>
                  <option value="Terminado">Terminado</option>
                </select>
                <label for="">Puntaje</label>
                <input type="number" v-model="videojuego.puntaje"><br>
                <p v-if="videojuego.puntaje < 1 || videojuego.puntaje > 10">El puntaje debe estar entre 1 y 10.</p>
                <button @click="cargarJuegos()">Agregar Juego</button>
              </div>
            </div>
          </th>
        </tr>
      </table>
      
      <h3>Listado de Juegos</h3>
      <table class="juegos-table">
        <tr>
          <th>Nombre</th>
          <th>Plataforma</th>
          <th>Estado</th>
          <th>Puntaje</th>
          <th>Acciones</th>
          <th>Más info</th>
        </tr>
        <tr v-for="(juego, index) in juegos" :key="index">
          <td>{{ juego.nombre }}</td>
          <td>{{ juego.plataforma }}</td>
          <td>{{ juego.estado }}</td>
          <td>{{ juego.puntaje }}</td>
          <td>
            <button @click="eliminarJuego(index)" class="btn-delete">Eliminar</button>
          </td>
          <td>
            <button @click="desplegar(index)" class="btn-mas">Más información</button>
            <!-- Contenido adicional mostrado sólo cuando se presiona "Más información" -->
            <div v-if="desplegado[index]" class="extra-info" :class="'extra-info-' + index">
              <p>Nombre: {{ juego.nombre }}</p>
              <p>Plataforma: {{ juego.plataforma }}</p>
              <p>Estado: {{ juego.estado }}</p>
              <p>Puntaje: {{ juego.puntaje }}</p>
            </div>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue'

let videojuego = ref({
  nombre: '',
  plataforma: '',
  estado: '',
  puntaje: 0,
  dis: '',
})

let juegos = ref([])

let desplegado = ref([])

function cargarJuegos() {
  if (
    videojuego.value.nombre &&
    videojuego.value.plataforma &&
    videojuego.value.estado &&
    videojuego.value.puntaje > 0 &&
    videojuego.value.puntaje <= 10
  ) {
    juegos.value.push({ ...videojuego.value })
    desplegado.value.push(false)
    
    videojuego.value.nombre = ''
    videojuego.value.plataforma = ''
    videojuego.value.estado = ''
    videojuego.value.puntaje = 0
  }
}


function eliminarJuego(index) {
  juegos.value.splice(index, 1)
  desplegado.value.splice(index, 1) 
}

function desplegar(index) {
  desplegado.value[index] = !desplegado.value[index]
}

</script>

<style scoped>
.display {
  display: none;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  min-height: 100vh;
  background-color: #9eb0ca;
  padding: 20px;
  box-sizing: border-box;
}

.content-box {
  width: 100%;
  max-width: 1100px;
  padding: 20px;
  background-color: #ffffff;
  border: 1px solid #000000;
  border-radius: 8px;
  box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  margin-bottom: 20px;
  color: #465379;
}

.contenedor {
  max-width: 1000px;
  margin-left: 0;
  padding: 100px;
  border: 1px solid #000000;
  border-radius: 8px;
  background-color: #848ba7;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
  color: #000000;
}

input[type="text"], input[type="number"], select {
  padding: 8px;
  width: 90%;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #ffffff;
}

button {
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  background-color: #5f6985;
  color: #ffffff;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: #000000;
}

.juegos-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  border: 1px solid #000000;
}

.juegos-table th, .juegos-table td {
  padding: 10px;
  border: 1px solid #000000;
  text-align: center;
}

.juegos-table th {
  background-color: #56648a;
  color: #ffffff;
  font-weight: bold;
}

.juegos-table tr:nth-child(even) {
  background-color: #e9ecef;
}

.juegos-table tr:hover {
  background-color: #d6d9e1;
}

.btn-delete {
  background-color: #e74c3c;
  color: #ffffff;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-mas {
  background-color: green;
  color: #ffffff;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-delete:hover {
  background-color: #c0392b;
}
.container {
  position: relative;
}

.extra-info {
  position: absolute;
  padding: 10px;
  border: 1px solid #000000;
  background-color: #f9f9f9;
  border-radius: 4px;
  width: 200px;
  text-align: center;
  margin-bottom: 20px;
  color: #000000;
}

.extra-info-0 {
  top: 120px;
  left: 850px;
}

.extra-info-1 {
  top: 120px;
  left: 850px;
}

.extra-info-2 {
  top: 120px;
  left: 850px;
}

.extra-info-3 {
  top: 120px;
  left: 850px;
}

</style>
